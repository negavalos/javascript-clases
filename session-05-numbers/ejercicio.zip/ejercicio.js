let AlturaEntero = 185;
let AlturaFlotante =1.85;
let pesoFloat = 89.3;

let AlturaRondeada = AlturaFlotante.toFixed(1);
console.log(AlturaRondeada);
let PesoRedondeado = pesoFloat.toPrecision(2);
console.log(PesoRedondeado);

let max_valor_js = Number.MAX_VALUE + 1;
console.log(max_valor_js);